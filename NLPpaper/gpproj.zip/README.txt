ToneAnalyzer.ipynb is the main code
code_result.pdf is the result of running code with 1000 tweets.
code_result.png is the image result of 1000 tweets that would not display in nbconvert
project_report.pdf is the main paper.
